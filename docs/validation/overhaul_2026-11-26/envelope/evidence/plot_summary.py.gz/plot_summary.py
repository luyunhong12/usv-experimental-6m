"""绘制原门槛与实际值，不改变验收结论。"""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
b=Path(__file__).resolve().parent;s=json.loads((b/'suite-summary.json').read_text());fig,axes=plt.subplots(1,2,figsize=(11,4))
for sign,label in [(-1,'-5 deg pulse'),(1,'+5 deg pulse')]:
 x=[];y=[]
 for throttle in [25,40,100]:
  name=f'pulse_{throttle}_{sign:+d}'
  if name in s['maneuvers']['cases']:
   value=s['maneuvers']['cases'][name]['stages']['pulse_recover']['settling_time_s']
   if value is not None:x.append(throttle);y.append(value)
   else:axes[0].scatter([throttle],[60],marker='x',color='red',s=75)
 axes[0].plot(x,y,'o-',label=label)
axes[0].annotate('100%: not settled within 60 s',(100,60),xytext=(52,44),fontsize=8,arrowprops={'arrowstyle':'->'})
axes[0].set_ylim(0,68)
axes[0].axhline(30,ls='--',color='red',label='Original 30 s limit');axes[0].set(xlabel='Reverse RPM command (%)',ylabel='Recovery time (s)',title='Fixed-load calm-water disturbance recovery');axes[0].legend();axes[0].grid(alpha=.3)
names=['wind5','combined','loaded_combined'];values=[s['environment']['cases'][n]['stages']['neutral']['tail_yaw_deg_s'] for n in names];axes[1].bar(['Wind 5 m/s','Wind + current + wave','Loaded combination'],values,color='indianred');axes[1].axhline(.172,ls='--',color='black',label='Original 0.172 deg/s limit');axes[1].set(ylabel='Tail yaw rate (deg/s)',title='Zero-helm environmental failures');axes[1].tick_params(axis='x',labelsize=8);axes[1].legend();fig.tight_layout();fig.savefig(b/'envelope-results.png',dpi=160)

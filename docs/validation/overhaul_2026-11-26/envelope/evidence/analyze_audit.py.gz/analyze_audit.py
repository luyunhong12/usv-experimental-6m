"""逐分量汇总尾段外力矩，统一到整船重心与船体坐标轴。"""
from pathlib import Path
import json,numpy as np
base=Path(__file__).resolve().parent;summary={}
for name in ['audit_normal','audit_zero_torque','audit_opposite_torque']:
 d=base/name
 if not (d/'result.json').exists():continue
 out=json.loads((d/'result.json').read_text());moments={}
 for file,groups in [('hull',['buoyancy','resistance_including_separation','added_inertia','air']),('appendages',['appendage']),('propeller',['thrust','water_torque'])]:
  a=np.loadtxt(d/(file+'.csv'),delimiter=',');tail=a[a[:,0]>a[-1,0]-15]
  for i,group in enumerate(groups):moments[group]=tail[:,4+6*i:10+6*i].mean(axis=0).tolist()
 r=np.loadtxt(d/'propulsion.csv',delimiter=',');a=np.loadtxt(d/'actuators.csv',delimiter=',');tail=r[r[:,0]>105];out.update(wrenches_Fxyz_N_Mxyz_Nm=moments,net_wrench=np.sum(list(moments.values()),axis=0).tolist(),tail_roll_pitch_deg=np.degrees(tail[:,15:17].mean(axis=0)).tolist(),tail_actual_steering_deg=float(np.degrees(a[a[:,0]>105,1].mean())))
 summary[name]=out
(base/'audit-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))

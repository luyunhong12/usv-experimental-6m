"""汇总原判据结果，额外执行原左右回转半径对称性门槛。"""
from pathlib import Path
import json,hashlib
import numpy as np
base=Path(__file__).resolve().parent;root=base.parents[2]
selection=json.loads((base/'selected-attempts.json').read_text())
criteria=json.loads((root/'tests/scenarios/maneuver_acceptance.json').read_text());spec=json.loads((base/'cases.json').read_text());envspec=json.loads((base/'cases_env.json').read_text());names=[n for n in spec if not n.startswith('audit')];groups={}
for group,expected in [('maneuvers',names),('environment',list(envspec))]:
 results={};missing=[]
 for name in expected:
  p=base/selection.get(name,name)/'result.json'
  if p.exists():
   result=json.loads(p.read_text());result['supplemental_checks']={}
   if name.startswith('pulse_'):
    act=np.loadtxt(p.parent/'actuators.csv',delimiter=',');events=json.loads((p.parent/'events.json').read_text());pulse=next(e for e in events if e['name']=='pulse');recover=next(e for e in events if e['name']=='pulse_recover')
    actual=act[(act[:,0]>=pulse['begin'])&(act[:,0]<pulse['end']+2),1];tail=act[act[:,0]>recover['end']-15,1];peak=float(np.degrees(abs(actual)).max());zero=float(np.degrees(abs(tail)).max());result['pulse_actual']={'peak_deg':peak,'tail_zero_max_deg':zero}
    result['supplemental_checks']={'disturbance_effective':peak>2,'actual_zero_rudder':zero<.1};result['passed'] &= all(result['supplemental_checks'].values())
   results[name]=result
  else:missing.append(name)
 groups[group]={'selected_attempts':{n:selection.get(n,n) for n in expected},'cases':results,'missing':missing,'all_completed':not missing,'passed':not missing and all(r['passed'] for r in results.values())}
paired={}
for prefix,stage in [('turn_055','turn'),('turn_100','turn'),('astern','astern_turn')]:
 cases=groups['maneuvers']['cases']
 if prefix+'_left' in cases and prefix+'_right' in cases:
  a=cases[prefix+'_left']['stages'][stage]['radius_m'];b=cases[prefix+'_right']['stages'][stage]['radius_m'];difference=abs(a-b)/((a+b)/2) if a and b else None
  paired[prefix]={'left_m':a,'right_m':b,'relative_difference':difference,'passed':difference is not None and difference<criteria['max_port_starboard_radius_relative_difference']}
groups['maneuvers']['paired_turns']=paired;groups['maneuvers']['passed'] &= len(paired)==3 and all(p['passed'] for p in paired.values())
binding=json.loads((base/'envelope-binding.json').read_text());groups['source_unchanged']=all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in binding.items());groups['promotion_passed']=groups['source_unchanged'] and groups['maneuvers']['passed'] and groups['environment']['passed'];(base/'suite-summary.json').write_text(json.dumps(groups,indent=2)+'\n')
for group in ['maneuvers','environment']:
 print(group,'completed',len(groups[group]['cases']),'missing',len(groups[group]['missing']))
 for n,r in groups[group]['cases'].items():
  failures=[k for k,v in r['checks'].items() if not v];print(' ',n,'PASS' if r['passed'] else 'FAIL',','.join(failures))
print('paired',paired,'source_unchanged',groups['source_unchanged'],'promotion',groups['promotion_passed'])

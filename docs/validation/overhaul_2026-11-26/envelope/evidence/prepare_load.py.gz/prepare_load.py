"""增加明确几何与惯性的300 kg试验载荷，并按新静态姿态重算剖面。"""
from pathlib import Path
import ast,json,sys,math
import numpy as np
import xml.etree.ElementTree as E
from scipy.optimize import root as solve
from scipy.spatial.transform import Rotation
root=Path('/home/yh/Project/usv-experimental-6m');sys.path.insert(0,str(root/'tools/lib'))
from mass_properties import aggregate
from section_hydrodynamics import lateral_inertia
base=root/'artifacts/rebuild/envelope-v1';dest=base/'payload300';dest.mkdir(exist_ok=False)
tree=E.parse(root/'artifacts/rebuild/separation-v1/physical/model.sdf');model=tree.getroot().find('model');hull=model.find("link[@name='hull']");i=hull.find('inertial');ic=i.find('inertia');cg=np.fromstring(i.findtext('pose'),sep=' ')[:3];tensor=np.array([[float(ic.findtext('ixx')),float(ic.findtext('ixy')),float(ic.findtext('ixz'))],[float(ic.findtext('ixy')),float(ic.findtext('iyy')),float(ic.findtext('iyz'))],[float(ic.findtext('ixz')),float(ic.findtext('iyz')),float(ic.findtext('izz'))]])
size=np.array([1.,.8,.5]);center=np.array([-.566057992234,0,.8]);mass=300.;inertia=np.diag(mass/12*np.array([size[1]**2+size[2]**2,size[0]**2+size[2]**2,size[0]**2+size[1]**2]));loaded=aggregate([dict(mass_kg=float(i.findtext('mass')),cg_m=cg.tolist(),inertia_at_cg_kg_m2=tensor.tolist()),dict(mass_kg=mass,cg_m=center.tolist(),inertia_at_cg_kg_m2=inertia.tolist())]);i.find('mass').text=str(loaded['mass_kg']);i.find('pose').text=' '.join(map(str,loaded['cg_m']+[0,0,0]))
for key,a,b in [('ixx',0,0),('iyy',1,1),('izz',2,2),('ixy',0,1),('ixz',0,2),('iyz',1,2)]:ic.find(key).text=str(loaded['inertia_at_cg_kg_m2'][a][b])
for kind in ['visual','collision']:
 node=E.SubElement(hull,kind,name='engineering_payload300');E.SubElement(node,'pose').text=' '.join(map(str,list(center)+[0,0,0]));E.SubElement(E.SubElement(E.SubElement(node,'geometry'),'box'),'size').text='1 .8 .5'
masses=[];centers=[]
for link in model.findall('link'):
 masses.append(float(link.findtext('inertial/mass')));centers.append(np.fromstring(link.findtext('pose'),sep=' ')[:3]+np.fromstring(link.findtext('inertial/pose'),sep=' ')[:3])
total=sum(masses);cg=sum(m*c for m,c in zip(masses,centers))/total
tri=np.loadtxt(root/'ros_ws/src/usv_description/config/hull_triangles.txt').reshape(-1,3,3)
f=next(x for x in ast.parse((root/'tools/lib/fuel_equilibrium.py').read_text()).body if isinstance(x,ast.FunctionDef) and x.name=='displaced');ns=dict(np=np,Rotation=Rotation,triangles=tri);exec(compile(ast.Module(body=[f],type_ignores=[]),'displaced','exec'),ns)
def residual(q):
 vol,cb,rot=ns['displaced'](q);worldcg=rot@cg+[0,0,q[0]];return [vol-total/1000,cb[0]-worldcg[0],cb[1]-worldcg[1]]
solution=solve(residual,[-.3,0,0]);assert solution.success and np.max(abs(np.array(residual(solution.x))))<1e-7
q=solution.x;assert abs(q[1])<1e-8 and abs(q[2])<.05
# Preserve body x and y; express the inclined waterplane as a horizontal cut in sheared z.
cut=tri.copy();cut[:,:,2]-=math.tan(q[2])*cut[:,:,0];water=-q[0]/math.cos(q[2]);hyd=model.find("plugin[@name='usv::HullHydrostatics']");ref=float(hyd.findtext('drag_center').split()[0]);est=lateral_inertia(cut,water,ref,strips=480);mat=np.array(est['sway_yaw_matrix']);s=np.array(est['sections_x_draft_beam_m']);mu=.5*1000*np.pi*s[:,1]**2
profile=np.vstack(([-3,0],[-3,mu[0]],np.column_stack((s[:,0],mu)),[3,mu[-1]],[3,0]));np.savetxt(dest/'sections.txt',profile,fmt='%.12g')
source=ast.parse((root/'artifacts/rebuild/section-hydro-v1/prepare.py').read_text());expr=next(n.value for n in source.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='data' for t in n.targets));data=eval(compile(ast.Expression(expr),'existing_hoerner_data','eval'),{'np':np});wet=s[:,1]>1e-10;cd=np.interp(s[wet,2]/(2*s[wet,1]),data[:,0],data[:,1]);budget=float(np.sum(.5*1000*cd*s[wet,1])*est['strip_width_m']);coefficient=budget*float(hyd.findtext('reference_projected_area').split()[1])/est['side_area_m2']
hyd.find('added_linear').text=f'70 {mat[0,0]:.15g} 250';hyd.find('added_angular').text=f'30 200 {mat[1,1]:.15g}';hyd.find('added_sway_yaw').text=str(mat[0,1]);hyd.find('quadratic_damping').text=f'178.002166055 {coefficient:.15g} 1800';hyd.find('separation_sections_file').text=str(dest/'sections.txt');tree.write(dest/'model.sdf')
result=dict(mass_kg=total,cg_m=cg.tolist(),equilibrium_z_roll_pitch=q.tolist(),residual=residual(q),volume_m3=total/1000,added_payload=dict(mass_kg=mass,center_m=center.tolist(),size_m=size.tolist(),inertia_kg_m2=inertia.tolist()),sections=est,crossflow_budget=budget,quadratic_y=coefficient,scope='Fixed 300kg engineering test block; small-trim body-vertical strip approximation; not measured hardware')
(dest/'equilibrium.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='sections'},indent=2))

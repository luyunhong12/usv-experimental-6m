import os,time,json,subprocess,signal,math
from pathlib import Path
import xml.etree.ElementTree as E
from gz.transport13 import Node
from gz.msgs10.double_pb2 import Double
from gz.msgs10.double_v_pb2 import Double_V
out=Path('/rebuild/simple-v1'); world=E.parse(out/'world.sdf'); w=world.getroot().find('world')
for p in list(w.findall('plugin')):
 if p.get('name')=='gz::sim::systems::Sensors': w.remove(p)
world.write(out/'smoke-world.sdf')
n=Node(); rows=[]; actuators=[]; energy=[]
def record(m): rows.append(list(m.data))
def servo(m): actuators.append(list(m.data))
def power(m): energy.append(list(m.data))
n.subscribe(Double_V,'/usv/propulsion/state',record)
n.subscribe(Double_V,'/usv/actuators/state',servo)
n.subscribe(Double_V,'/usv/energy/truth',power)
a=n.advertise('/usv/propulsion/throttle',Double); b=n.advertise('/usv/steering/angle',Double)
log=(out/'runtime.log').open('w'); p=subprocess.Popen(['gz','sim','-s','-r',str(out/'smoke-world.sdf')],stdout=log,stderr=log,start_new_session=True)
start=time.monotonic()
try:
 while time.monotonic()-start<240:
  t=rows[-1][0] if rows else 0
  if t>=150: break
  thrust=0 if t<25 or 55<=t<75 or t>=135 else (.3 if t<55 or t>=105 else -.3)
  angle=.35 if 105<=t<120 else (-.35 if 120<=t<135 else 0)
  a.publish(Double(data=thrust));b.publish(Double(data=angle));time.sleep(.05)
finally:
 a.publish(Double(data=0));b.publish(Double(data=0));os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 log.close()
checks={'completed':bool(rows and rows[-1][0]>=150),'finite':bool(rows) and all(math.isfinite(v) for r in rows for v in r),'no_energy_messages':not energy,'six_actuator_fields':bool(actuators) and all(len(r)==6 for r in actuators)}
for name,lo,hi,index,sgn in [('forward',45,55,10,1),('reverse',95,105,10,-1),('left_angle',115,120,1,1),('right_angle',130,135,1,-1)]:
 data=actuators if 'angle' in name else rows
 vals=[r[index] for r in data if lo<=r[0]<hi];checks[name]=bool(vals) and sgn*sum(vals)/len(vals)>.1
rest=[r for r in rows if 15<r[0]<25]
checks['static_attitude']=bool(rest) and max(abs(r[15]) for r in rest)<math.radians(5) and max(abs(r[16]) for r in rest)<math.radians(5)
(out/'smoke-result.json').write_text(json.dumps({'checks':checks,'samples':len(rows),'last_time':rows[-1][0] if rows else None,'scope':'150s isolated still water, no rendering system, no SITL; smoke not maneuver acceptance'},indent=2))
(out/'propulsion.json').write_text(json.dumps(rows));(out/'actuators.json').write_text(json.dumps(actuators))
print(json.dumps(checks));raise SystemExit(0 if all(checks.values()) else 1)

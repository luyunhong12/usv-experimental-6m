"""固定高功率静水模型的剖面估计和隔离候选；不更改默认船模。"""
from pathlib import Path
import sys,json,shutil,hashlib
import xml.etree.ElementTree as E
import numpy as np
root=Path('/home/yh/Project/usv-experimental-6m');sys.path.insert(0,str(root/'tools/lib'))
from section_hydrodynamics import lateral_inertia
base=root/'artifacts/rebuild/section-hydro-v1';original=root/'artifacts/rebuild/simple-speed15-v1/model.sdf';mesh=np.loadtxt(root/'ros_ws/src/usv_description/config/hull_triangles.txt').reshape(-1,3,3)
water=.25261623933582933;ref=-.642065682056
runs={str(n):lateral_inertia(mesh,water,ref,strips=n) for n in [60,120,240,480]}
(base/'section-estimates.json').write_text(json.dumps(runs,indent=2)+'\n')
r=runs['480'];matrix=np.array(r['sway_yaw_matrix']);sections=np.array(r['sections_x_draft_beam_m']);wet=sections[:,1]>1e-10
# Hoerner table, MSS/HYDRO/Hoerner.m; scientific data interpolation, not a fitted gain.
data=np.array([[.0108623,1.96608],[.176606,1.96573],[.353025,1.89756],[.451863,1.78718],[.472838,1.58374],[.492877,1.27862],[.493252,1.21082],[.558473,1.08356],[.646401,.998631],[.833589,.87959],[.988002,.828415],[1.30807,.759941],[1.63918,.691442],[1.85998,.657076],[2.31288,.630693],[2.59998,.596186],[3.00877,.586846],[3.45075,.585909],[3.7379,.559877],[4.00309,.559315]])
cd=np.interp(sections[wet,2]/(2*sections[wet,1]),data[:,0],data[:,1]);budget=float(np.sum(.5*1000*cd*sections[wet,1])*r['strip_width_m'])
summary={'source_sha256':hashlib.sha256(original.read_bytes()).hexdigest(),'water_z_m':water,'reference_x_m':ref,'added_sway_kg':matrix[0,0],'added_sway_yaw_kg_m':matrix[0,1],'added_yaw_kg_m2':matrix[1,1],'inertia_center_x_m':r['inertia_center_x_m'],'crossflow_sway_budget_N_s2_m2':budget,'side_area_m2':r['side_area_m2'],'Cd_min_max': [float(min(cd)),float(max(cd))]}
for name in ['inertia','inertia_crossflow']:
 d=base/name;d.mkdir(exist_ok=False);tree=E.parse(original);h=tree.getroot().find("model/plugin[@name='usv::HullHydrostatics']");h.find('added_linear').text=f'70 {matrix[0,0]:.15g} 250';h.find('added_angular').text=f'30 200 {matrix[1,1]:.15g}';E.SubElement(h,'added_sway_yaw').text=f'{matrix[0,1]:.15g}'
 if name=='inertia_crossflow':
  # Same existing projected-area spatial distribution, new total cross-flow budget.
  coefficient=budget*float(h.findtext('reference_projected_area').split()[1])/r['side_area_m2'];h.find('quadratic_damping').text=f'178.002166055 {coefficient:.15g} 1800';summary['candidate_quadratic_y']=coefficient
 tree.write(d/'model.sdf');world=E.parse(root/'artifacts/rebuild/simple-speed15-v1/world.sdf');world.getroot().find('world/include/uri').text=str(d/'model.sdf');world.write(d/'world.sdf');shutil.copy(root/'artifacts/rebuild/recovery-speed15-v1/equilibrium.json',d/'equilibrium.json')
 s=(root/'artifacts/rebuild/recovery-speed15-v1/run.py').read_text().replace('/rebuild/recovery-speed15-v1',f'/rebuild/section-hydro-v1/{name}').replace('/rebuild/simple-speed15-v1/world.sdf',f'/rebuild/section-hydro-v1/{name}/world.sdf');(d/'run.py').write_text(s)
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
for n,r in runs.items():print(n,np.array(r['sway_yaw_matrix']).ravel(),r['side_area_m2'])

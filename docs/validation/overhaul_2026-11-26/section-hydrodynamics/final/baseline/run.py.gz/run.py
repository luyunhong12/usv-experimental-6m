import os,time,json,subprocess,signal,math,sys,ast
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
from gz.transport13 import Node
from gz.msgs10.double_pb2 import Double
from gz.msgs10.double_v_pb2 import Double_V
root=Path('/home/yh/Project/usv-experimental-6m');base=Path('/rebuild/section-hydro-v1/final/baseline');case=sys.argv[1];out=base/case;out.mkdir(exist_ok=False)
eq=json.loads((base/'equilibrium.json').read_text());world=E.parse('/rebuild/section-hydro-v1/final/baseline/world.sdf');w=world.getroot().find('world');w.set('name','simple_'+case)
for p in list(w.findall('plugin')):
 if p.get('name')=='gz::sim::systems::Sensors':w.remove(p)
pose=[0,0,*[eq['equilibrium_z_roll_pitch'][0]],eq['equilibrium_z_roll_pitch'][1],eq['equilibrium_z_roll_pitch'][2],0]
if case=='disturbed':pose[2]+=.08;pose[3]+=math.radians(5);pose[4]+=math.radians(2)
w.find('include/pose').text=' '.join(map(str,pose));world.write(out/'world.sdf')
n=Node();rows=[];act=[];hyd=[];commands=[]
def rec(m):rows.append(list(m.data))
def servo(m):act.append(list(m.data))
def buoy(m):hyd.append(list(m.data))
n.subscribe(Double_V,'/usv/propulsion/state',rec);n.subscribe(Double_V,'/usv/actuators/state',servo);n.subscribe(Double_V,'/usv/hydrostatics',buoy)
a=n.advertise('/usv/propulsion/throttle',Double);b=n.advertise('/usv/steering/angle',Double)
log=(out/'runtime.log').open('w');p=subprocess.Popen(['gz','sim','-s','-r',str(out/'world.sdf')],stdout=log,stderr=log,start_new_session=True)
start=time.monotonic();reverse=case.startswith('reverse');duration=162 if reverse else 40;laststage=None
try:
 while time.monotonic()-start<500:
  t=rows[-1][0] if rows else 0
  if t>=duration or p.poll() is not None:break
  throttle=-.6 if reverse else 0; angle=(math.radians(5)*(1 if case.endswith('left') else -1)) if reverse and 100<=t<102 else 0
  stage=0 if t<100 else (1 if t<102 else 2)
  if stage!=laststage:commands.append([t,throttle,angle]);laststage=stage
  a.publish(Double(data=throttle));b.publish(Double(data=angle));time.sleep(.02)
finally:
 a.publish(Double(data=0));b.publish(Double(data=0));os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 log.close()
for name,data in [('propulsion',rows),('actuators',act),('hydrostatics',hyd),('commands',commands)]:np.savetxt(out/(name+'.csv'),data,delimiter=',')
r=np.asarray(rows);h=np.asarray(hyd);ac=np.asarray(act)
checks={'completed':len(r)>10 and r[-1,0]>=duration,'finite':all(np.isfinite(x).all() for x in [r,h,ac]),'continuous':len(r)>10 and np.max(np.diff(r[:,0]))<.3};metrics={}
if not reverse and len(h)>10:
 tail=h[h[:,0]>duration-5];errors=np.max(abs(tail[:,[8,9,10]]-eq['equilibrium_z_roll_pitch']),axis=0)
 checks['equilibrium_error']=bool(np.all(errors<[.01,.01,.01]));checks['displacement']=abs(tail[-1,1]-eq['volume_m3'])<.02
 metrics={'tail_max_pose_error':errors.tolist(),'final_pose':tail[-1,[8,9,10]].tolist(),'displacement_m3':float(tail[-1,1])}
if reverse and len(r)>100 and len(commands)==3:
 tree=ast.parse((root/'tests/regression/assess_maneuvers.py').read_text());funcs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['speed_rate','recovery_metrics']];ns={'np':np,'math':math};exec(compile(ast.Module(body=funcs,type_ignores=[]),'existing_assessment','exec'),ns)
 criteria=json.loads((root/'tests/scenarios/reverse_task_acceptance.json').read_text());c1,c2=commands[1][0],commands[2][0];before=r[(r[:,0]>c1-15)&(r[:,0]<c1)];after=r[r[:,0]>=c2];reference=math.degrees(ns['speed_rate'](before));metrics=ns['recovery_metrics'](after,criteria['reverse_rate_recovery_tolerance_deg_s'],reference)
 metrics.update(reference_yaw_deg_s=reference,tail_yaw_deg_s=math.degrees(ns['speed_rate'](after[after[:,0]>after[-1,0]-15])),tail_surge_m_s=float(after[-150:,10].mean()),peak_actual_pulse_deg=float(np.degrees(abs(ac[(ac[:,0]>=c1)&(ac[:,0]<c2+2),1])).max()))
 checks['disturbance_effective']=metrics['peak_actual_pulse_deg']>2
 checks['disturbance_recovery']=metrics['settling_time_s'] is not None and metrics['settling_time_s']<=criteria['reverse_rate_recovery_time_s']
 checks['tail_yaw_bounded']=abs(metrics['tail_yaw_deg_s'])<criteria['max_reverse_yaw_deg_s']
 checks['actual_zero_rudder']=float(np.degrees(abs(ac[ac[:,0]>147,1])).max())<.1
 checks['direct_reverse']=bool(np.all(after[:,1]==-.6))
result={'case':case,'checks':{k:bool(v) for k,v in checks.items()},'metrics':metrics,'passed':all(checks.values()),'scope':'40kW speed15 concept fixed-load no-fin candidate; existing criteria unchanged; no heading controller'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

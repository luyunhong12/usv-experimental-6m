// Diagnostic only: planar, fixed trim and surge, production force functions.
#include "WavePressure.hh"
#include "AppendageHydrodynamics.hh"
#include "Resistance.hh"
#include "AddedMass.hh"
#include <fstream>
#include <iostream>
#include <iomanip>
using namespace usv;
int main(){
 std::ifstream in("/source/ros_ws/src/usv_description/config/hull_triangles.txt");
 auto mesh=ReadAppendageBuoyancyMesh(in);std::vector<Triangle> refined;
 for(auto &t:mesh)RefineTriangle(t,.35,refined);
 std::vector<LateralPatch> patches;
 const double cg=-.5660579922343724,z=-.25261623933582933,drag=-.642065682056;
 for(auto&t:refined){PressureResult p;AccumulatePressure(t,{-z-t[0].Z(),-z-t[1].Z(),-z-t[2].Z()},9810,p);
 if(p.wetArea>1e-12){auto n=(t[1]-t[0]).Cross(t[2]-t[0]).Normalized();patches.push_back({p.wetFirstMoment.X()/p.wetArea-cg,.5*p.wetArea*std::abs(n.Y()),p.wetArea});}}
 std::ifstream surfaces("/evidence/surfaces.txt");int count;double azimuthX,azimuthZ;surfaces>>count>>azimuthX>>azimuthZ;
 std::vector<WetSurface> wet;std::vector<double> cds,effs;
 for(int k=0;k<count;++k){int n;double cd,e;surfaces>>n>>cd>>e;std::vector<V> pts(n);std::vector<double> depth;
 for(auto&p:pts){surfaces>>p.X()>>p.Y()>>p.Z();depth.push_back(-z-azimuthZ-p.Z());}wet.push_back(ClipAppendage(pts,depth));cds.push_back(cd);effs.push_back(e);}
 std::cout<<std::setprecision(17);
 for(double u:{-.7,-1.884})for(int variant=0;variant<3;++variant){
  // Columns: acceleration/velocity unit perturbations at whole-vessel CG.
  for(int column=0;column<4;++column){double eps=1e-6,v=column==0?eps:0,r=column==1?eps:0,dv=column==2?eps:0,dr=column==3?eps:0;
   auto hull=DistributedLateralDrag(patches,v,r,600/10.330756862389416,1500/1.23285511366);
   double y=hull.force,n=hull.moment;
   if(variant!=2)for(size_t i=0;i<wet.size();++i){double x=azimuthX+wet[i].center.X()-cg;auto f=AppendageForce(1000,wet[i].area,wet[i].span,cds[i],effs[i],V(u,v+x*r,0));y+=f.Y();n+=x*f.Y();}
   if(variant!=1){double d=drag-cg;auto a=AddedMassWrench(V(70,250,250),V(30,200,200),V(u,v+d*r,0),V(0,0,r),V(0,dv+d*dr,0),V(0,0,dr));y+=a.force.Y();n+=a.torque.Z()+d*a.force.Y();}
   std::cout<<u<<" "<<variant<<" "<<column<<" "<<y/eps<<" "<<n/eps<<"\n";
  }
 }
}

"""一次性CFD几何预检：导出原压力船壳与碰撞附体，不自动封洞或改变外形。"""
from pathlib import Path
import json,hashlib,xml.etree.ElementTree as E
import numpy as np
import trimesh
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.spatial.transform import Rotation
r=Path('/home/yh/Project/usv-experimental-6m');b=r/'artifacts/rebuild/towing-v1';out=b/'cfd-preflight-v2';out.mkdir(exist_ok=False)
m=E.parse(r/'artifacts/rebuild/refinement-v1/air_base/model.sdf').find('model');eq=json.loads((r/'artifacts/rebuild/recovery-speed15-v1/equilibrium.json').read_text())['equilibrium_z_roll_pitch'];rot=Rotation.from_euler('xyz',[*eq[1:],0]).as_matrix();sources={};reports={};n={'c':'http://www.collada.org/2005/11/COLLADASchema'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def report(name,mesh):
 mesh.apply_transform(np.block([[rot,np.array([[0],[0],[eq[0]]])],[np.zeros((1,3)),np.ones((1,1))]]));mesh.export(out/(name+'.stl'))
 counts=np.bincount(mesh.edges_unique_inverse);adj=mesh.face_adjacency;graph=coo_matrix((np.ones(len(adj)),(adj[:,0],adj[:,1])),shape=(len(mesh.faces),len(mesh.faces)));part_count,labels=connected_components(graph,directed=False);tri=mesh.triangles;volume=np.einsum("ij,ij->i",tri[:,0],np.cross(tri[:,1],tri[:,2]))/6;part_volumes=np.bincount(labels,weights=volume)
 reports[name]={'vertices':len(mesh.vertices),'triangles':len(mesh.faces),'bounds_world_m':mesh.bounds.tolist(),'watertight':bool(mesh.is_watertight),'winding_consistent':bool(mesh.is_winding_consistent),'signed_volume_m3':float(mesh.volume),'boundary_edges':int(sum(counts==1)),'nonmanifold_edges':int(sum(counts>2)),'components':int(part_count),'component_volumes_m3':part_volumes.tolist(),'positive_closed_solid':bool(mesh.is_volume),'self_intersection_checked':False,'stl_sha256':sha(out/(name+'.stl'))}
p=Path(m.findtext("plugin[@name='usv::HullHydrostatics']/triangles_file"));sources[str(p)]=sha(p);tri=np.loadtxt(p).reshape(-1,3,3);mesh=trimesh.Trimesh(tri.reshape(-1,3),np.arange(tri.size//3).reshape(-1,3),process=True);report('hull',mesh)
for name in ['azimuth','propeller']:
 link=m.find(f"link[@name='{name}']");p=Path(link.findtext('collision/geometry/mesh/uri'));sources[str(p)]=sha(p);xml=E.parse(p)
 assert len(xml.findall('.//c:geometry',n))==1
 assert not any(xml.findall('.//c:node/c:'+tag,n) for tag in ['matrix','translate','rotate','scale'])
 assert xml.find('.//c:unit',n).get('meter')=='1'
 assert xml.findtext('.//c:up_axis',namespaces=n)=='Z_UP'
 pos=xml.find(".//c:source[@id='pos']/c:float_array",n);vertices=np.fromstring(pos.text,sep=' ').reshape(-1,3);faces=[]
 for t in xml.findall('.//c:triangles',n):
  inputs=t.findall('c:input',n);stride=max(int(i.get('offset')) for i in inputs)+1;index=next(int(i.get('offset')) for i in inputs if i.get('semantic')=='VERTEX');faces.extend(np.fromstring(t.findtext('c:p',namespaces=n),sep=' ',dtype=int).reshape(-1,stride)[:,index].reshape(-1,3))
 pose=np.fromstring(link.findtext('pose'),sep=' ');vertices=vertices@Rotation.from_euler('xyz',pose[3:]).as_matrix().T+pose[:3];mesh=trimesh.Trimesh(vertices,np.asarray(faces),process=True);report(name,mesh)
report={'status':'PREFLIGHT_ONLY_NOT_CFD_READY','coordinate_system':'world axes aligned with hull at equilibrium; water z=0; metres','equilibrium_z_roll_pitch':eq,'source_sha256':sources,'surfaces':reports,'remaining':['Separate connected parts are not automatically a watertight Boolean union','Intersecting/internal surfaces and hull-appendage junction require review','No volume mesh, solver, wall treatment or CFD result has been validated','Rotating propeller omitted in initial bare-hull CFD; powered comparisons require separate validated propulsor model']}
(out/'geometry-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(reports,indent=2))

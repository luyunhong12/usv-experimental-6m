import os,time,json,subprocess,signal
from pathlib import Path
import xml.etree.ElementTree as E
from gz.transport13 import Node
from gz.msgs10.vector3d_pb2 import Vector3d
from gz.msgs10.double_v_pb2 import Double_V
r=Path('/home/yh/Project/usv-experimental-6m');b=r/'artifacts/rebuild/towing-v1';tree=E.parse(r/'artifacts/rebuild/refinement-v1/air_base/model.sdf');m=tree.find('model');E.SubElement(m,'static').text='true'
for p in list(m.findall('plugin')):
 if p.get('name') not in ['usv::HullHydrostatics','usv::AppendageHydrodynamics']:m.remove(p)
for link in m.findall('link'):
 for sensor in list(link.findall('sensor')):link.remove(sensor)
h=m.find("plugin[@name='usv::HullHydrostatics']");h.find('air_cd_area').text='0 0 0';tree.write(b/'model.sdf')
w=E.Element('sdf',version='1.9');world=E.SubElement(w,'world',name='tow');E.SubElement(world,'gravity').text='0 0 -9.81';physics=E.SubElement(world,'physics',name='physics',type='ignored');E.SubElement(physics,'max_step_size').text='.001';E.SubElement(physics,'real_time_factor').text='1';E.SubElement(world,'plugin',filename='gz-sim-physics-system',name='gz::sim::systems::Physics');inc=E.SubElement(world,'include');E.SubElement(inc,'uri').text=str(b/'model.sdf');E.SubElement(inc,'pose').text='0 0 -.25261623933582933 0 0 0';E.ElementTree(w).write(b/'world.sdf')
log=(b/'smoke.log').open('w');p=subprocess.Popen(['gz','sim','-s','-r',str(b/'world.sdf')],stdout=log,stderr=log,start_new_session=True);n=Node();data={};callbacks=[]
for key,topic in [('hull','audit/hull'),('appendages','audit/appendages'),('separation','hydrodynamics/separation'),('pose','hydrostatics')]:
 data[key]=[]
 def capture(msg,key=key):data[key].append(list(msg.data))
 callbacks.append(capture);n.subscribe(Double_V,'/usv/'+topic,capture)
current=n.advertise('/vrx/current/velocity',Vector3d)
try:
 for i in range(150):
  if p.poll() is not None:raise RuntimeError('Gazebo exited')
  current.publish(Vector3d(x=3.43,y=-.1,z=0));time.sleep(.1)
finally:
 os.killpg(p.pid,signal.SIGINT);p.wait(timeout=20)
(b/'smoke.json').write_text(json.dumps(data));print({k:(len(v),v[-1] if v else None) for k,v in data.items()})

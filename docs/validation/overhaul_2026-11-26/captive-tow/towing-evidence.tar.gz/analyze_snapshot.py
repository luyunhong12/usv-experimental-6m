"""一次性归纳固定拖曳矩阵，不拟合或修改生产参数。"""
import json,hashlib
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
r=Path('/home/yh/Project/usv-experimental-6m');b=r/'artifacts/rebuild/towing-v1';d=r/'docs/validation/overhaul_2026-11-26/captive-tow';d.mkdir(exist_ok=True)
s=json.loads((b/'sweep/summary.json').read_text());idx={(x['u_m_s'],x['beta_deg']):x for x in s['cases']};derivatives=[]
for u in sorted({key[0] for key in idx}):
 for beta in [.5,1,2]:
  pos,neg=idx[u,beta],idx[u,-beta];dv=pos['v_m_s']-neg['v_m_s'];entry={'u_m_s':u,'half_angle_deg':beta}
  for name in pos['components_N_Nm']:
   delta=(np.array(pos['components_N_Nm'][name])-neg['components_N_Nm'][name])/dv;entry[name]={'Y_v_N_per_m_s':float(delta[1]),'N_v_Nm_per_m_s':float(delta[5])}
  total=(np.array(pos['total_N_Nm'])-neg['total_N_Nm'])/dv;entry['total']={'Y_v_N_per_m_s':float(total[1]),'N_v_Nm_per_m_s':float(total[5])};derivatives.append(entry)
sym=max(np.max(abs(np.array(c['total_N_Nm'])[[1,5]]+np.array(idx[u,-beta]['total_N_Nm'])[[1,5]])) for (u,beta),c in idx.items());foreaft=max(abs(c['total_N_Nm'][1]-idx[-u,beta]['total_N_Nm'][1]) for (u,beta),c in idx.items());numerical={}
for name in ['halfstep','refined']:
 v=json.loads((b/name/'summary.json').read_text());numerical[name]={'cases':len(v['cases']),'all_valid':all(x['valid'] for x in v['cases']),'source_unchanged':v['source_unchanged'],'max_abs_wrench_difference_N_Nm':max(float(np.max(abs(np.array(x['total_N_Nm'])-idx[x['u_m_s'],x['beta_deg']]['total_N_Nm']))) for x in v['cases'])}
result={'scope':'INTERNAL_MODEL_TEST_NOT_INDEPENDENT_VALIDATION','sweep_cases':len(s['cases']),'all_valid':all(c['valid'] for c in s['cases']),'source_unchanged':s['source_unchanged'],'max_mirror_Y_N_residual_N_Nm':sym,'max_ahead_astern_Y_difference_N':foreaft,'numerical_checks':numerical,'derivatives':derivatives,'limitations':['No yaw-rate excitation: Y_r and N_r are not identified','No rotating propeller or wake, no free heave/roll/pitch','Static rig excludes the reaction-torque-induced heel seen in free runs','No CFD or independent experimental measurements']};(d/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
fig,axes=plt.subplots(1,2,figsize=(11,4))
for u,label in [(3.43,'Ahead'),(-3.43,'Astern')]:
 cases=sorted([c for (speed,_),c in idx.items() if speed==u],key=lambda c:c['beta_deg']);x=[c['beta_deg'] for c in cases]
 for j,col in enumerate([1,5]):axes[j].plot(x,[c['total_N_Nm'][col] for c in cases],'o-',label=label)
for ax,label in zip(axes,['Side force Y (N)','Yaw moment about CG (N m)']):ax.set(xlabel='Oblique angle beta (deg)',ylabel=label);ax.grid(alpha=.3);ax.legend()
fig.suptitle('Existing Gazebo model: |u| = 3.43 m/s, fixed pose, no powered propeller\nInternal consistency test — not CFD validation');fig.tight_layout();fig.savefig(d/'tow-curves.png',dpi=160);print(json.dumps({k:v for k,v in result.items() if k!='derivatives'},indent=2))

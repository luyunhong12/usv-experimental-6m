"""归档一次性启动试验原始证据与图表。"""
from pathlib import Path
import hashlib,json,tarfile,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
b=Path(__file__).parent
d=Path('docs/validation/overhaul_2026-11-26/cfd-startup')
shutil.copy2(b/'final-results.json',d/'final-results.json')
index={}
with tarfile.open(d/'final-evidence.tar.gz','w:gz') as tar:
 for name in ['static','reverse-zero','reverse-minus','reverse-plus']:
  p=b/f'final-{name}-v3'
  paths=[q for q in p.iterdir() if q.is_file() and (q.name.startswith('log.') or q.suffix in ['.json','.txt'])]
  paths+=list((p/'system').glob('*'))
  paths+=[p/'constant'/name for name in ['g','transportProperties','turbulenceProperties']]
  paths+=list((p/'postProcessing').rglob('*.dat'))
  for q in paths:
   if not q.is_file():continue
   relative=str(q.relative_to(b));index[relative]=hashlib.sha256(q.read_bytes()).hexdigest();tar.add(q,arcname=relative)
 for name in ['evaluate-final.py','archive-final.py']:
  tar.add(b/name,arcname=name);index[name]=hashlib.sha256((b/name).read_bytes()).hexdigest()
(d/'final-evidence-sha256.json').write_text(json.dumps(index,indent=2)+'\n')
fig,axes=plt.subplots(1,2,figsize=(10,3.7),layout='constrained')
for name,label in [('reverse-zero','beta = 0 deg'),('reverse-minus','beta = -2 deg'),('reverse-plus','beta = +2 deg'),('reflected','reflected mesh, beta = +2 deg')]:
 p=(b/'reflected-reverse-plus/postProcessing/forces/0') if name=='reflected' else b/f'final-{name}-v3/postProcessing/forces/0'
 for ax,file,col in [(axes[0],'force',2),(axes[1],'moment',3)]:
  data=np.loadtxt(p/f'{file}.dat');ax.plot(data[:,0],data[:,col],label=label,linewidth=1.5,linestyle='--' if name=='reflected' else '-')
for ax,title,unit in zip(axes,['Lateral force','Yaw moment about CG'],['Fy (N)','Nz (N m)']):
 ax.set(title=title,xlabel='Time (s)',ylabel=unit,xlim=(0,.02));ax.grid(alpha=.25);ax.axhline(0,color='gray',linewidth=.5)
axes[0].legend(fontsize=8)
fig.suptitle('Fixed bare hull, reverse 3.43 m/s: STARTUP ONLY, not steady coefficients',fontsize=10)
fig.savefig(d/'startup-forces.png',dpi=160)

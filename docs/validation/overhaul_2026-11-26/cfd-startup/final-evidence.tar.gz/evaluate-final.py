"""本轮一次性证据汇总；不是船体运行入口。"""
from pathlib import Path
import hashlib,json,re
import numpy as np
b=Path(__file__).parent
plan=json.loads((b/'validation-plan.json').read_text())
results={}
for name in ['static','reverse-zero','reverse-minus','reverse-plus']:
 p=b/f'final-{name}-v3'
 log=(p/'log.interFoam').read_text()
 manifest=json.loads((p/'manifest.json').read_text())
 force=np.loadtxt(p/'postProcessing/forces/0/force.dat',ndmin=2)
 moment=np.loadtxt(p/'postProcessing/forces/0/moment.dat',ndmin=2)
 values=lambda pattern:[float(x) for x in re.findall(pattern,log,re.M)]
 times=values(r'^Time = (\S+)')
 dt=values(r'^deltaT = (\S+)')
 amin=values(r'Min\(alpha.water\) = (\S+)')
 amax=values(r'Max\(alpha.water\) = (\S+)')
 speed=values(r'max\(mag\(U\)\) = (\S+)')
 actual={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for folder in ['0','constant','system'] for q in (p/folder).rglob('*') if q.is_file()}
 (p/'initialized-input-sha256.json').write_text(json.dumps(actual,indent=2)+'\n')
 unchanged=all(actual.get(k)==v for k,v in manifest['case_sha256'].items() if k.startswith(('system/','constant/')))
 checks={
 'exit_zero':(p/'exit-code.txt').read_text().strip()=='0',
 'end_reached':bool(re.search(r'^End\s*$',log,re.M)) and abs(times[-1]-manifest['duration_s'])<1e-8 and abs(force[-1,0]-manifest['duration_s'])<1e-8 and abs(moment[-1,0]-manifest['duration_s'])<1e-8,
 'mesh_ok':'Mesh OK.' in (p/'log.checkMesh').read_text(),
 'alpha_bounded':min(amin)>=plan['numeric_limits']['alpha_min'] and max(amax)<=plan['numeric_limits']['alpha_max'],
 'timestep':min(dt)>=plan['numeric_limits']['min_timestep_s'],
 'finite_forces':bool(np.isfinite(force).all() and np.isfinite(moment).all()),
 'inputs_unchanged':unchanged}
 y=re.findall(r'patch hull y\+ : min = (\S+), max = (\S+), average = (\S+)',log)
 result={'checks':checks,'complete':bool(checks['end_reached']),'duration_s':times[-1],'steps':len(times),'alpha_min':min(amin),'alpha_max':max(amax),'min_dt_s':min(dt),'max_logged_speed_m_s':max(speed),'final_force_N':force[-1,1:4].tolist(),'final_moment_Nm':moment[-1,1:4].tolist(),'wall_s':values(r'ClockTime = ([0-9.]+) s')[-1],'final_yplus_min_max_mean':list(map(float,y[-1])) if y else None}
 if name=='static':
  buoyancy=9.81*(1000*1.5711745300420836+1.225*(8.35823787018325-1.5711745300420836))
  limit=plan['static_limits']
  result['max_abs_Fx_Fy_N']=np.max(np.abs(force[:,1:3]),axis=0).tolist()
  result['max_abs_Nz_Nm']=float(np.max(np.abs(moment[:,3])))
  result['max_buoyancy_relative_error']=float(np.max(np.abs(force[:,3]-buoyancy))/buoyancy)
  checks.update({'static_speed':max(speed)<=limit['max_speed_m_s'],'static_horizontal_force':max(result['max_abs_Fx_Fy_N'])<=limit['abs_Fx_Fy_N'],'static_yaw':result['max_abs_Nz_Nm']<=limit['abs_yaw_moment_Nm'],'buoyancy':result['max_buoyancy_relative_error']<=limit['buoyancy_relative_error']})
 if name=='reverse-zero':
  checks.update({'zero_beta_Fy':abs(force[-1,2])<=plan['mirror_screen']['zero_beta_abs_Fy_N'],'zero_beta_Nz':abs(moment[-1,3])<=plan['mirror_screen']['zero_beta_abs_Nz_Nm']})
 result['checks']={k:bool(v) for k,v in checks.items()}
 result['startup_pass']=all(checks.values())
 results[name]=result
mirror={}
for label,key,index in [('Fy','final_force_N',1),('Nz','final_moment_Nm',2)]:
 a=results['reverse-minus'][key][index];c=results['reverse-plus'][key][index]
 error=abs(a+c)/max(.5*(abs(a)+abs(c)),1.)
 mirror[label]={'relative_error':error,'limit':plan['mirror_screen']['relative_error'],'pass':error<=plan['mirror_screen']['relative_error']}
out={'scope':'STARTUP_ONLY_NOT_STEADY_OR_MANOEUVRING_ACCEPTANCE','cases':results,'final_time_mirror':mirror,'all_startup_screens_pass':all(r['startup_pass'] for r in results.values()) and all(r['pass'] for r in mirror.values())}
(b/'final-results.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

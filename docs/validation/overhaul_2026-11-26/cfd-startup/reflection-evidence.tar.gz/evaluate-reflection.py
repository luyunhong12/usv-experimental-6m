"""镜像网格诊断：不替代原网格的5%门禁。"""
from pathlib import Path
import re,json,hashlib,numpy as np,tarfile,shutil
b=Path(__file__).parent;d=Path('docs/validation/overhaul_2026-11-26/cfd-startup');p=b/'reflected-reverse-plus';log=(p/'log.interFoam').read_text();manifest=json.loads((p/'manifest.json').read_text())
actual={str(q.relative_to(p)):hashlib.sha256(q.read_bytes()).hexdigest() for folder in ['0','constant','system'] for q in (p/folder).rglob('*') if q.is_file()}
(p/'initialized-input-sha256.json').write_text(json.dumps(actual,indent=2)+'\n')
r={'scope':'diagnostic reflection; original mesh mirror gate remains FAILED','end_reached':bool(re.search(r'^End\s*$',log,re.M)) and abs(float(re.findall(r'^Time = (\S+)',log,re.M)[-1])-.02)<1e-8,'mesh_ok':'Mesh OK.' in (p/'log.checkMesh').read_text(),'inputs_unchanged':all(actual.get(k)==v for k,v in manifest['case_sha256'].items() if k.startswith(('system/','constant/'))),'min_dt_s':min(map(float,re.findall(r'^deltaT = (\S+)',log,re.M))),'alpha_min':min(map(float,re.findall(r'Min\(alpha.water\) = (\S+)',log))),'alpha_max':max(map(float,re.findall(r'Max\(alpha.water\) = (\S+)',log))),'wall_s':float(re.findall(r'ClockTime = ([0-9.]+) s',log)[-1]),'comparisons':{}}
for name,col,label in [('force',2,'Fy'),('moment',3,'Nz')]:
 a=np.loadtxt(b/f'final-reverse-minus-v3/postProcessing/forces/0/{name}.dat');c=np.loadtxt(p/f'postProcessing/forces/0/{name}.dat');mask=(c[:,0]>=a[0,0])&(c[:,0]<=a[-1,0]);v=np.interp(c[mask,0],a[:,0],a[:,col]);w=c[mask,col];err=np.abs(v+w)/np.maximum(.5*(np.abs(v)+np.abs(w)),1.)
 r['comparisons'][label]={'original_minus':float(a[-1,col]),'reflected_plus':float(c[-1,col]),'final_relative_error':float(abs(a[-1,col]+c[-1,col])/max(.5*(abs(a[-1,col])+abs(c[-1,col])),1.)),'max_interpolated_history_relative_error':float(err.max())}
(d/'reflection-results.json').write_text(json.dumps(r,indent=2)+'\n');shutil.copy2(b/'geometry-symmetry.json',d/'geometry-symmetry.json')
index={}
with tarfile.open(d/'reflection-evidence.tar.gz','w:gz') as tar:
 paths=[q for q in p.iterdir() if q.is_file() and (q.name.startswith('log.') or q.suffix in ['.json','.txt'])]+list((p/'system').glob('*'))+list((p/'postProcessing').rglob('*.dat'))+[b/'waterline-reflected/reflection.json',Path(__file__)]
 for q in paths:
  if q.is_file():
   rel=str(q.relative_to(b));tar.add(q,arcname=rel);index[rel]=hashlib.sha256(q.read_bytes()).hexdigest()
(d/'reflection-evidence-sha256.json').write_text(json.dumps(index,indent=2)+'\n');print(json.dumps(r,indent=2))

from pathlib import Path
import trimesh,numpy as np,io,json,sys
b=Path(__file__).parent;name=sys.argv[1];src=trimesh.load(b/'diagnostic/constant/triSurface/hull.stl',process=True)
s=(b/name/'boundary.stl').read_text();s=s[s.index('solid hull'):s.index('endsolid hull')+len('endsolid hull')]
h=trimesh.load(io.BytesIO(s.encode()),file_type='stl',process=True)
pts=np.vstack([h.vertices,h.triangles_center]);ds=[]
for i in range(0,len(pts),100):ds.extend(trimesh.proximity.closest_point_naive(src,pts[i:i+100])[1])
reverse=trimesh.proximity.closest_point_naive(h,np.vstack([src.vertices,src.triangles_center]))[1]
r={'input_vertices':len(src.vertices),'input_triangles':len(src.faces),'mesh_boundary_triangles':len(h.faces),'input_volume_m3':abs(src.volume),'boundary_volume_m3':abs(h.volume),'volume_relative_error':abs(abs(h.volume)/abs(src.volume)-1),'input_area_m2':src.area,'boundary_area_m2':h.area,'boundary_sample_max_distance_m':float(max(ds)),'source_sample_max_distance_m':float(max(reverse)),'input_bounds':src.bounds.tolist(),'boundary_bounds':h.bounds.tolist(),'boundary_watertight':h.is_watertight}
(b/name/'geometry-comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))

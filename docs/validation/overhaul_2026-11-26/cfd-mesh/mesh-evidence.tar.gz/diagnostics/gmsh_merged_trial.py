from pathlib import Path
import gmsh, trimesh
b=Path(__file__).parent;p=b/'gmsh-merged';p.mkdir(exist_ok=True)
h=trimesh.load(b/'diagnostic/constant/triSurface/hull.stl',process=True)
gmsh.initialize();gmsh.option.setNumber('General.NumThreads',4);gmsh.model.add('bare-hull');g=gmsh.model.geo
pts=[g.addPoint(*v,.125) for v in h.vertices];edges={};surfs=[]
# Merge only adjacent, outward-normal-aligned coplanar triangles.
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
adj=h.face_adjacency
mask=np.einsum('ij,ij->i',h.face_normals[adj[:,0]],h.face_normals[adj[:,1]])>1-1e-12
pairs=adj[mask];_,labels=connected_components(coo_matrix((np.ones(len(pairs)),(pairs[:,0],pairs[:,1])),shape=(len(h.faces),len(h.faces))),directed=False)
polygons=[]
for group in np.unique(labels):
 triangles=h.faces[labels==group];boundary={}
 for face in triangles:
  for a,b_ in zip(face,(*face[1:],face[0])):
   if (b_,a) in boundary:del boundary[(b_,a)]
   else:boundary[(a,b_)]=True
 nxt=dict(boundary.keys());start=next(iter(nxt));face=[start];cur=nxt[start]
 while cur!=start:face.append(cur);cur=nxt[cur]
 assert len(face)==len(boundary)
 polygons.append(face)
print('Merged planar surfaces:',len(polygons),flush=True)
for face in polygons:
 ls=[]
 for a,b_ in zip(face,(*face[1:],face[0])):
  key=tuple(sorted((int(a),int(b_))))
  if key not in edges:edges[key]=g.addLine(pts[key[0]],pts[key[1]])
  ls.append(edges[key]*(1 if a<b_ else -1))
 surfs.append(g.addPlaneSurface([g.addCurveLoop(ls)]))
inner=g.addSurfaceLoop(surfs)
vs=[[-24,-12,-12],[24,-12,-12],[24,12,-12],[-24,12,-12],[-24,-12,6],[24,-12,6],[24,12,6],[-24,12,6]]
ps=[g.addPoint(*v,.75) for v in vs];ed={};outer=[]
for name,q in {'xmin':[0,4,7,3],'xmax':[1,2,6,5],'ymin':[0,1,5,4],'ymax':[3,7,6,2],'bottom':[0,3,2,1],'top':[4,5,6,7]}.items():
 ls=[]
 for a,b_ in zip(q,q[1:]+q[:1]):
  key=tuple(sorted((a,b_)))
  if key not in ed:ed[key]=g.addLine(ps[key[0]],ps[key[1]])
  ls.append(ed[key]*(1 if a<b_ else -1))
 surf=g.addPlaneSurface([g.addCurveLoop(ls)]);outer.append((name,surf))
v=g.addVolume([g.addSurfaceLoop([s for _,s in outer]),inner]);g.synchronize()
gmsh.model.addPhysicalGroup(3,[v],name='fluid');gmsh.model.addPhysicalGroup(2,surfs,name='hull')
for name,s in outer:gmsh.model.addPhysicalGroup(2,[s],name=name)
f=gmsh.model.mesh.field.add('Box')
for key,value in {'VIn':.25,'VOut':.75,'XMin':-9,'XMax':9,'YMin':-3,'YMax':3,'ZMin':-.5,'ZMax':.5,'Thickness':.5}.items():gmsh.model.mesh.field.setNumber(f,key,value)
gmsh.model.mesh.field.setAsBackgroundMesh(f)
gmsh.option.setNumber('Mesh.MshFileVersion',2.2);gmsh.option.setNumber('Mesh.OptimizeNetgen',1);gmsh.option.setNumber('Mesh.MeshSizeMax',.75)
gmsh.model.mesh.generate(3);gmsh.write(str(p/'mesh.msh'));gmsh.finalize()

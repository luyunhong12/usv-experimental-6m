from pathlib import Path
import shutil,numpy as np,trimesh
b=Path(__file__).parent;case=b/'tet-v2';src=b/'diagnostic';shutil.copytree(src/'system',case/'system');(case/'constant/triSurface').mkdir(parents=True)
v=np.array([[-24,-12,-12],[24,-12,-12],[24,12,-12],[-24,12,-12],[-24,-12,6],[24,-12,6],[24,12,6],[-24,12,6]])
faces={'xmin':[0,4,7,3],'xmax':[1,2,6,5],'ymin':[0,1,5,4],'ymax':[3,7,6,2],'bottom':[0,3,2,1],'top':[4,5,6,7]}
parts={name:np.array([v[[q[0],q[1],q[2]]],v[[q[0],q[2],q[3]]]]) for name,q in faces.items()}
h=trimesh.load(src/'constant/triSurface/hull.stl',process=False);parts['hull']=h.triangles[:,[0,2,1]]
with (case/'constant/triSurface/domain.stl').open('w') as f:
 for name,tri in parts.items():
  f.write(f'solid {name}\n')
  for t in tri:
   n=np.cross(t[1]-t[0],t[2]-t[0]).astype(float);n/=np.linalg.norm(n);f.write('facet normal '+' '.join(map(str,n))+'\nouter loop\n')
   for p in t:f.write('vertex '+' '.join(map(str,p))+'\n')
   f.write('endloop\nendfacet\n')
  f.write(f'endsolid {name}\n')
(case/'system/meshDict').write_text('''FoamFile { version 2.0; format ascii; class dictionary; object meshDict; }
surfaceFile "constant/triSurface/domain.stl";
maxCellSize 0.75;
localRefinement { hull { cellSize 0.125; refinementThickness .5; } }
objectRefinements { freeSurface { type box; centre (0 0 0); lengthX 18; lengthY 6; lengthZ 1; cellSize .25; } }
renameBoundary { defaultName farfield; defaultType patch; newPatchNames { hull { newName hull; type wall; } } }
''')

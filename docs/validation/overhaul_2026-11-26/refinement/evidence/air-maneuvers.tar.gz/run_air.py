"""固定模型的直接命令包络试验快照；无航向保持控制。"""
import os,time,json,subprocess,signal,math,sys,importlib.util
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
from gz.transport13 import Node
from gz.msgs10.double_pb2 import Double
from gz.msgs10.vector3d_pb2 import Vector3d
from gz.msgs10.world_control_pb2 import WorldControl
from gz.msgs10.boolean_pb2 import Boolean
from gz.msgs10.double_v_pb2 import Double_V
root=Path('/home/yh/Project/usv-experimental-6m');base=root/'artifacts/rebuild/refinement-v1';name=sys.argv[1];cfg=json.loads((base/'cases_air.json').read_text())[name];out=base/name;out.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('metrics',root/'tests/regression/assess_maneuvers.py');metrics=importlib.util.module_from_spec(spec);spec.loader.exec_module(metrics)
model=E.parse(cfg.get('model',str(root/'artifacts/rebuild/separation-v1/physical/model.sdf')))
prop=model.getroot().find("model/plugin[@name='usv::AzimuthPropulsion']")
if 'water_torque_scale' in cfg:
 el=prop.find('diagnostic_water_torque_scale')
 if el is None:el=E.SubElement(prop,'diagnostic_water_torque_scale')
 el.text=str(cfg['water_torque_scale'])
for wave in model.findall('.//wavefield/wave'):
 for key,value in [('gain',cfg.get('wave_gain',0)),('period',4),('direction',cfg.get('wave_direction',0))]:
  el=wave.find(key)
  if el is None:el=E.SubElement(wave,key)
  el.text=str(value)
if cfg.get('appendage_scale') == 0:
 parent=model.getroot().find('model');parent.remove(parent.find("plugin[@name='usv::AppendageHydrodynamics']"))
model.write(out/'model.sdf');world=E.parse(root/'artifacts/rebuild/separation-v1/physical/world.sdf');w=world.getroot().find('world');w.set('name','envelope_'+name);w.find('include/uri').text=str(out/'model.sdf')
for p in list(w.findall('plugin')):
 if p.get('name')=='gz::sim::systems::Sensors':w.remove(p)
eq=json.loads(Path(cfg.get('equilibrium',str(root/'artifacts/rebuild/recovery-speed15-v1/equilibrium.json'))).read_text());w.find('include/pose').text=' '.join(map(str,[0,0,*eq['equilibrium_z_roll_pitch'],0]));
if cfg.get('step'):w.find('physics/max_step_size').text=str(cfg['step'])
world.write(out/'world.sdf')
log=(out/'runtime.log').open('w');process=subprocess.Popen(['gz','sim','-s',str(out/'world.sdf')],stdout=log,stderr=log,start_new_session=True)
time.sleep(2)
node=Node();data={};callbacks=[]
for key,topic in {'propulsion':'propulsion/state','actuators':'actuators/state','hydrostatics':'hydrostatics','separation':'hydrodynamics/separation','hull':'audit/hull','propeller':'audit/propulsion','appendages':'audit/appendages','environment':'environment/state','wave_response_state':'wave_response/state'}.items():
 data[key]=[]
 def capture(m,key=key):data[key].append(list(m.data))
 callbacks.append(capture);node.subscribe(Double_V,'/usv/'+topic,capture)
a=node.advertise('/usv/propulsion/throttle',Double);b=node.advertise('/usv/steering/angle',Double)
wind_pub=node.advertise('/vrx/wind/velocity',Vector3d);current_pub=node.advertise('/vrx/current/velocity',Vector3d)
connection_start=time.monotonic()
while not all(p.has_connections() for p in [a,b,wind_pub,current_pub]):
 if process.poll() is not None:raise RuntimeError('Gazebo exited during configuration; inspect runtime.log')
 if time.monotonic()-connection_start>30:
  os.killpg(process.pid,signal.SIGINT);process.wait(timeout=10)
  raise RuntimeError('Command transport connection failed before unpause')
 time.sleep(.1)
first=cfg['stages'][0];a.publish(Double(data=first['throttle']));b.publish(Double(data=math.radians(first.get('steering_deg',0))))
wind_pub.publish(Vector3d(x=cfg.get('wind',[0,0,0])[0],y=cfg.get('wind',[0,0,0])[1],z=0));current_pub.publish(Vector3d(x=cfg.get('current',[0,0,0])[0],y=cfg.get('current',[0,0,0])[1],z=0))
time.sleep(.2)
ok,response=node.request('/world/envelope_'+name+'/control',WorldControl(pause=False),WorldControl,Boolean,5000)
if not ok or not response.data:
 os.killpg(process.pid,signal.SIGINT);process.wait(timeout=10)
 raise RuntimeError('World unpause failed')
start=time.monotonic();events=[];idx=0;stages=cfg['stages'];stage_start=0;origin=None;complete=False
try:
 while time.monotonic()-start<1200:
  rows=data['propulsion'];t=rows[-1][0] if rows else 0
  if process.poll() is not None:break
  if not rows and time.monotonic()-start>30:break
  stage=stages[idx]
  if not events:events.append(dict(stage,begin=t))
  heading_reached=False
  if rows and origin is not None and 'until_heading_deg' in stage:
   heading=math.degrees(math.atan2(math.sin(rows[-1][14]-origin),math.cos(rows[-1][14]-origin)))
   target=stage['until_heading_deg'];heading_reached=heading>=target if target>0 else heading<=target
  if t-stage_start>=stage['duration'] or heading_reached:
   events[-1].update(end=t,heading_reached=heading_reached);idx+=1
   if idx==len(stages):complete=True;break
   stage=stages[idx];stage_start=t
   if origin is None and 'until_heading_deg' in stage:origin=rows[-1][14]
   events.append(dict(stage,begin=t))
  wind_pub.publish(Vector3d(x=cfg.get('wind',[0,0,0])[0],y=cfg.get('wind',[0,0,0])[1],z=0));current_pub.publish(Vector3d(x=cfg.get('current',[0,0,0])[0],y=cfg.get('current',[0,0,0])[1],z=0))
  a.publish(Double(data=stage['throttle']));b.publish(Double(data=math.radians(stage.get('steering_deg',0))));time.sleep(.01)
finally:
 a.publish(Double(data=0));b.publish(Double(data=0))
 if process.poll() is None:
  os.killpg(process.pid,signal.SIGINT)
  try:process.wait(timeout=10)
  except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
 log.close()
for key,values in data.items():np.savetxt(out/(key+'.csv'),values,delimiter=',')
(out/'events.json').write_text(json.dumps(events,indent=2)+'\n')
crit=json.loads((root/'tests/scenarios/maneuver_acceptance.json').read_text());rev=json.loads((root/'tests/scenarios/reverse_task_acceptance.json').read_text())
r=np.asarray(data['propulsion']);act=np.asarray(data['actuators']);se=np.asarray(data['separation'])
checks={'completed':complete,'finite_continuous':all(metrics.valid_trace(np.asarray(data[k])) for k in ['propulsion','actuators','hydrostatics']),'attitude':len(r)>0 and np.degrees(abs(r[:,15:17])).max()<crit['max_roll_pitch_deg']}
result={'case':name,'scope':cfg.get('scope','fixed-load direct-command screening'),'checks':checks,'stages':{}}
for ev in events:
 if 'end' not in ev:continue
 x=r[(r[:,0]>=ev['begin'])&(r[:,0]<=ev['end'])]
 if len(x)<5:checks['stage_data_'+ev['name']]=False;continue
 sm=metrics.stage_metrics(x);result['stages'][ev['name']]=sm;n=ev['name']
 if n in ['neutral','reverse']:
  limit=crit['max_neutral_yaw_deg_s'] if n=='neutral' else crit['max_reverse_yaw_deg_s'];checks[n+'_yaw']=abs(sm['tail_yaw_deg_s'])<limit;checks[n+'_speed_std']=sm['tail_speed_std_m_s']<crit['max_tail_speed_std_m_s']
 if n in ['turn','astern_turn']:
  sm.update(metrics.turning_metrics(x));rad=sm['radius_m'];checks[n+'_radius']=rad is not None and crit['min_turn_radius_lengths']*6<=rad<=crit['max_turn_radius_lengths']*6
 if n in ['coast','reverse_brake']:
  sm.update(metrics.stop_metrics(x,reverse=n=='reverse_brake'));lim=crit['max_reverse_brake_stop_distance_lengths'] if n=='reverse_brake' else crit['max_coast_stop_distance_lengths'];checks[n+'_stop']=sm['stop_distance_m'] is not None and sm['stop_distance_m']<lim*6
 if n=='recover':
  sm.update(metrics.recovery_metrics(x,crit['max_recovered_yaw_deg_s']));checks[n+'_time']=sm['settling_time_s'] is not None and sm['settling_time_s']<=crit['max_recovery_time_s'];checks[n+'_heading']=sm['extra_heading_deg']<crit['max_recovery_heading_deg']
 if n=='pulse_recover':
  before=r[(r[:,0]>events[0]['end']-15)&(r[:,0]<events[0]['end'])];reference=math.degrees(metrics.speed_rate(before));sm.update(metrics.recovery_metrics(x,rev['reverse_rate_recovery_tolerance_deg_s'],reference));checks[n+'_time']=sm['settling_time_s'] is not None and sm['settling_time_s']<=rev['reverse_rate_recovery_time_s'];checks[n+'_tail']=abs(sm['tail_yaw_deg_s'])<rev['max_reverse_yaw_deg_s']
 if 'until_heading_deg' in ev:checks[n+'_trigger']=ev['heading_reached']
# Execute original complete stage/servo/zigzag rules in addition to pulse-specific checks.
stored=[];traces=[]
for ev in events:
 if 'end' not in ev:continue
 stage=dict(ev,start_sim=ev['begin'],end_sim=ev['end'],heading_reference_rad=origin,heading_triggered=ev['heading_reached']);stored.append(stage)
 x=r[(r[:,0]>=ev['begin'])&(r[:,0]<=ev['end'])];traces.append(x)
 if len(x)<5:continue
 chk=metrics.held_stage_checks(stage,x,act,crit);chk.update(metrics.motion_checks(stage,x,result['stages'][ev['name']],crit));checks.update({ev['name']+'_'+k:v for k,v in chk.items()})
servo,result['servo']=metrics.servo_checks(model.getroot().find('model'),act);checks.update(servo)
zig,result['overshoots_deg']=metrics.zigzag_checks(stored,traces,crit);checks.update(zig)
env_criteria=json.loads((root/'tests/scenarios/environment_acceptance.json').read_text())
env_checks,result['environment']=metrics.environment_quality(out,r,cfg,env_criteria);checks.update(env_checks)
env=np.asarray(data['environment']);tail=env[env[:,0]>20];checks['wind_delivered']=bool(len(tail) and np.max(abs(tail[:,7:10]-cfg.get('wind',[0,0,0])))<1e-8)
if cfg.get('wave_gain',0)==0:checks['current_delivered']=bool(len(tail) and np.max(abs(tail[:,4:7]-cfg.get('current',[0,0,0])))<1e-8)
if len(se):checks['separation_passive']=bool(np.max(se[:,2]*se[:,4]+se[:,3]*se[:,5])<=1e-8)
result['checks']={k:bool(v) for k,v in checks.items()};result['passed']=all(checks.values());(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

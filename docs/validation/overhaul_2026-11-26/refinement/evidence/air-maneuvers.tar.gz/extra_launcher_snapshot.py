import subprocess,concurrent.futures,sys
from pathlib import Path
root=Path('/home/yh/Project/usv-experimental-6m');base=root/'artifacts/rebuild/refinement-v1'
def run(name):
 args=['docker','run','--rm','--name','usv-refinement-'+name.replace('+','p'),'--network','host','--user','1000:1000','-e','GZ_IP=127.0.0.1','-e','GZ_PARTITION=refinement_'+name,'-v',f'{root}:{root}','-v',f'{root}/artifacts/rebuild/build/libUsvAzimuthPropulsion.so:/work/usv/ros_ws/install/usv_simulation/lib/libUsvAzimuthPropulsion.so:ro','-v',f'{root}/artifacts/rebuild/refinement-v1/build/libUsvHullHydrostatics.so:/work/usv/ros_ws/install/usv_simulation/lib/libUsvHullHydrostatics.so:ro','usv-simulation:sitl-gui','bash','-c',f'source /opt/ros/jazzy/setup.bash && source ros_ws/install/setup.bash && export GZ_SIM_SYSTEM_PLUGIN_PATH=/work/usv/ros_ws/install/usv_physics/lib:/work/usv/ros_ws/install/usv_simulation/lib:${{GZ_SIM_SYSTEM_PLUGIN_PATH:-}} && python3 {base}/run_air_extra.py {name}']
 with (base/(name+'.launcher.log')).open('w') as out:result=subprocess.run(args,stdout=out,stderr=subprocess.STDOUT)
 print(name,result.returncode,flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:list(pool.map(run,sys.argv[1:]))

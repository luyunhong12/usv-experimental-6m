import json,hashlib,subprocess
from pathlib import Path
import numpy as np
r=Path('/home/yh/Project/usv-experimental-6m');b=r/'artifacts/rebuild/refinement-v1'
cases=json.loads((b/'cases_air.json').read_text());extra=json.loads((b/'cases_air_extra.json').read_text());envnames=set(json.loads((r/'artifacts/rebuild/envelope-v1/cases_env.json').read_text()));results={}
for n in cases|extra:
 p=b/n/'result.json';result=json.loads(p.read_text());supp={}
 if 'pulse_recover' in result['stages']:
  a=np.loadtxt(b/n/'actuators.csv',delimiter=',');events=json.loads((b/n/'events.json').read_text());pulse=next(x for x in events if x['name']=='pulse');recover=next(x for x in events if x['name']=='pulse_recover')
  pulse_actual=a[(a[:,0]>=pulse['begin'])&(a[:,0]<=pulse['end']),1];tail=a[(a[:,0]>recover['end']-5)&(a[:,0]<=recover['end']),1]
  supp={'actual_pulse_exceeds_2deg':bool(np.degrees(abs(pulse_actual)).max()>2),'actual_tail_zero_below_0p1deg':bool(np.degrees(abs(tail)).max()<.1)}
 result['supplemental_checks']=supp;result['passed']=result['passed'] and all(supp.values());results[n]=result
criteria=json.loads((r/'tests/scenarios/maneuver_acceptance.json').read_text());pairs={}
for group,stage in [('turn_055','turn'),('turn_100','turn'),('astern','astern_turn')]:
 left=results[group+'_left']['stages'][stage]['radius_m'];right=results[group+'_right']['stages'][stage]['radius_m'];diff=abs(left-right)/((left+right)/2);pairs[group]={'left_m':left,'right_m':right,'relative_difference':diff,'passed':diff<=criteria['max_port_starboard_radius_relative_difference']}
summary={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=r,text=True).strip(),'image':'sha256:9a39de035e72e6d673e2b72dd39f33d20741e3990e60eded78ee2fb6adb5de45','cases':results,'paired_turns':pairs,'counts':{}}
for group,names in [('maneuvers',[n for n in cases if n not in envnames]),('environment',list(envnames)),('supplemental_60',list(extra))]:summary['counts'][group]={'passed':sum(results[n]['passed'] for n in names),'total':len(names)}
summary['promotion_allowed']=all(x['passed'] for x in results.values()) and all(x['passed'] for x in pairs.values())
binding=json.loads((b/'air-binding.json').read_text());summary['source_unchanged']=all(hashlib.sha256((r/p).read_bytes()).hexdigest()==h for p,h in binding['sha256'].items());assert summary['source_unchanged'];summary['promotion_allowed'] &= summary['source_unchanged']
summary['failed_checks']={n:[k for k,v in d['checks'].items() if not v] for n,d in results.items() if not d['passed']}
(b/'air-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='cases'},indent=2))

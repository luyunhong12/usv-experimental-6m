"""一次性诊断：由生产力函数导数组装固定纵速的平面线性系统。"""
import json
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
p=Path(__file__).parent
m=E.parse(p.parent/'simple-speed15-v1/model.sdf').getroot().find('model')
cg=np.array([-.5660579922343724,0,.4918677352423693]);mass=0;izz=0
for link in m.findall('link'):
 a=float(link.findtext('inertial/mass'));pose=np.fromstring(link.findtext('pose'),sep=' ');ip=np.fromstring(link.findtext('inertial/pose'),sep=' ')
 assert np.all(pose[3:]==0) and np.all(ip[3:]==0)
 pos=pose[:3]+ip[:3];mass+=a;izz+=float(link.findtext('inertial/inertia/izz'))+a*np.sum((pos[:2]-cg[:2])**2)
data=np.loadtxt(p/'linear-coefficients.txt');out=[]
for u in [-1.884,-2.27,-2.66,-3.05,-3.43]:
 for variant in range(3):
  rows=data[(data[:,0]==u)&(data[:,1]==variant)];K=rows[:2,3:].T.copy();K[0,1]-=mass*u;M=np.diag([mass,izz])-rows[2:,3:].T;A=np.linalg.solve(M,K)
  out.append(dict(surge_m_s=u,variant=['baseline','no_added','no_appendage'][variant],mass_matrix=M.tolist(),force_jacobian=K.tolist(),eigenvalues_per_s=np.linalg.eigvals(A).tolist()))
(p/'linear-results.json').write_text(json.dumps(dict(mass_kg=mass,izz_kg_m2=izz,scope='fixed trim, planar, fixed surge; neglect roll/heave/pitch and propeller reaction; not full 6DOF proof',results=out),indent=2))

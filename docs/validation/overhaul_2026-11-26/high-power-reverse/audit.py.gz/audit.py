import json,time
from pathlib import Path
from gz.transport13 import Node
from gz.msgs10.double_v_pb2 import Double_V
n=Node();data={name:[] for name in ('hull','appendages','propulsion')};callbacks=[]
for name in data:
 def rec(m,key=name):data[key].append(list(m.data))
 callbacks.append(rec);n.subscribe(Double_V,'/usv/audit/'+name,rec)
start=time.monotonic()
while time.monotonic()-start<240:
 if data['hull'] and data['hull'][-1][0]>160:break
 time.sleep(.1)
Path('/rebuild/recovery-speed15-v1/neutral-audit.json').write_text(json.dumps(data))
print({k:len(v) for k,v in data.items()})

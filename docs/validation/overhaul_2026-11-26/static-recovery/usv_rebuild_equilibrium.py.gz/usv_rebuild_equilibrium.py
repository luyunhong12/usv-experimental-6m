import ast,json,sys
from pathlib import Path
import numpy as np
import xml.etree.ElementTree as E
from scipy.optimize import root
from scipy.spatial.transform import Rotation
r=Path('/home/yh/Project/usv-experimental-6m')
source=r/'tools/lib/fuel_equilibrium.py'
f=next(n for n in ast.parse(source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='displaced')
namespace={'np':np,'Rotation':Rotation,'triangles':np.loadtxt(r/'ros_ws/src/usv_description/config/hull_triangles.txt').reshape(-1,3,3)}
exec(compile(ast.Module(body=[f],type_ignores=[]),str(source),'exec'),namespace)
model=E.parse(r/'artifacts/rebuild/simple-v1/model.sdf').getroot().find('model')
masses=[];centers=[]
for link in model.findall('link'):
 mass=float(link.findtext('inertial/mass'));pos=np.fromstring(link.findtext('pose'),sep=' ');ip=np.fromstring(link.findtext('inertial/pose'),sep=' ')
 assert np.all(pos[3:]==0) and np.all(ip[3:]==0)
 masses.append(mass);centers.append(pos[:3]+ip[:3])
mass=sum(masses);cg=sum(m*c for m,c in zip(masses,centers))/mass
rho=float(model.findtext("plugin[@name='usv::HullHydrostatics']/density"))
def residual(q):
 vol,cb,rot=namespace['displaced'](q);worldcg=rot@cg+[0,0,q[0]]
 return [vol-mass/rho,cb[0]-worldcg[0],cb[1]-worldcg[1]]
sol=root(residual,[-.214,0,-.003]);assert sol.success and np.max(np.abs(residual(sol.x)))<1e-7
out={'mass_kg':mass,'cg_m':cg.tolist(),'equilibrium_z_roll_pitch':sol.x.tolist(),'volume_m3':mass/rho,'residual':residual(sol.x),'scope':'Hull-only clipped volume, no fin; fixed assembled mass. Appendage buoyancy is not modeled by existing plugin.'}
(r/'artifacts/rebuild/recovery-v1/equilibrium.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out))

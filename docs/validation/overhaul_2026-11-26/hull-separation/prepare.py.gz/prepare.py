"""仅构建隔离的固定吃水分离候选，不覆盖默认船模。"""
from pathlib import Path
import json,shutil,hashlib
import xml.etree.ElementTree as E
import numpy as np
root=Path('/home/yh/Project/usv-experimental-6m');base=root/'artifacts/rebuild/separation-v1'
s=json.loads((root/'artifacts/rebuild/section-hydro-v1/section-estimates.json').read_text())['480'];a=np.array(s['sections_x_draft_beam_m']);mu=.5*1000*np.pi*a[:,1]**2
profile=np.vstack(([-3,0],[-3,mu[0]],np.column_stack((a[:,0],mu)),[3,mu[-1]],[3,0]));np.savetxt(base/'sections.txt',profile,fmt='%.12g')
for name,source in [('physical','inertia_crossflow'),('legacy_drag','inertia')]:
 d=base/name;d.mkdir();t=E.parse(root/f'artifacts/rebuild/section-hydro-v1/{source}/model.sdf');p=t.getroot().find("model/plugin[@name='usv::HullHydrostatics']");E.SubElement(p,'separation_sections_file').text=str(base/'sections.txt');t.write(d/'model.sdf');w=E.parse(root/'artifacts/rebuild/simple-speed15-v1/world.sdf');w.getroot().find('world/include/uri').text=str(d/'model.sdf');w.write(d/'world.sdf');shutil.copy(root/'artifacts/rebuild/recovery-speed15-v1/equilibrium.json',d/'equilibrium.json')
 run=(root/'artifacts/rebuild/recovery-speed15-v1/run.py').read_text().replace('/rebuild/recovery-speed15-v1',f'/rebuild/separation-v1/{name}').replace('/rebuild/simple-speed15-v1/world.sdf',f'/rebuild/separation-v1/{name}/world.sdf')
 run=run.replace('commands=[]','commands=[];sep=[]').replace('def buoy(m):hyd.append(list(m.data))','def buoy(m):hyd.append(list(m.data))\ndef separated(m):sep.append(list(m.data))').replace("a=n.advertise", "n.subscribe(Double_V,'/usv/hydrodynamics/separation',separated)\na=n.advertise").replace("('commands',commands)","('commands',commands),('separation',sep)")
 (d/'run.py').write_text(run)
files=['ros_ws/src/usv_simulation/include/HullSeparation.hh','ros_ws/src/usv_simulation/include/AddedMass.hh','ros_ws/src/usv_simulation/src/HullHydrostatics.cc','ros_ws/src/usv_simulation/tests/test_resistance.cc'];h={}
for name in files:
 p=root/name;h[name]=hashlib.sha256(p.read_bytes()).hexdigest();(base/p.name).write_bytes(p.read_bytes())
h['sections.txt']=hashlib.sha256((base/'sections.txt').read_bytes()).hexdigest();(base/'source-sha256.json').write_text(json.dumps(h,indent=2)+'\n')
print('sections',len(profile),'peak range',a[mu==max(mu),0][[0,-1]])

import os,time,json,subprocess,signal,math,sys,ast
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
from gz.transport13 import Node
from gz.msgs10.double_pb2 import Double
from gz.msgs10.double_v_pb2 import Double_V
root=Path('/home/yh/Project/usv-experimental-6m');base=Path('/rebuild/separation-v1/physical');case=sys.argv[1];out=base/case;out.mkdir(exist_ok=False)
eq=json.loads((base/'equilibrium.json').read_text());world=E.parse('/rebuild/separation-v1/physical/world.sdf');w=world.getroot().find('world');w.set('name','simple_'+case)
for p in list(w.findall('plugin')):
 if p.get('name')=='gz::sim::systems::Sensors':w.remove(p)
pose=[0,0,*[eq['equilibrium_z_roll_pitch'][0]],eq['equilibrium_z_roll_pitch'][1],eq['equilibrium_z_roll_pitch'][2],0]
if case=='disturbed':pose[2]+=.08;pose[3]+=math.radians(5);pose[4]+=math.radians(2)
w.find('include/pose').text=' '.join(map(str,pose));world.write(out/'world.sdf')
n=Node();rows=[];act=[];hyd=[];commands=[];sep=[]
def rec(m):rows.append(list(m.data))
def servo(m):act.append(list(m.data))
def buoy(m):hyd.append(list(m.data))
def separated(m):sep.append(list(m.data))
n.subscribe(Double_V,'/usv/propulsion/state',rec);n.subscribe(Double_V,'/usv/actuators/state',servo);n.subscribe(Double_V,'/usv/hydrostatics',buoy)
n.subscribe(Double_V,'/usv/hydrodynamics/separation',separated)
a=n.advertise('/usv/propulsion/throttle',Double);b=n.advertise('/usv/steering/angle',Double)
log=(out/'runtime.log').open('w');p=subprocess.Popen(['gz','sim','-s','-r',str(out/'world.sdf')],stdout=log,stderr=log,start_new_session=True)
start=time.monotonic();reverse=case.startswith('reverse');duration=240 if reverse else 100;laststage=None
try:
 while time.monotonic()-start<500:
  t=rows[-1][0] if rows else 0
  if t>=duration or p.poll() is not None:break
  throttle=-.6 if reverse else 1; angle=0 #(math.radians(5)*(1 if case.endswith('left') else -1)) if reverse and 100<=t<102 else 0
  stage=0 if t<100 else (1 if t<102 else 2)
  if stage!=laststage:commands.append([t,throttle,angle]);laststage=stage
  a.publish(Double(data=throttle));b.publish(Double(data=angle));time.sleep(.02)
finally:
 a.publish(Double(data=0));b.publish(Double(data=0));os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 log.close()
for name,data in [('propulsion',rows),('actuators',act),('hydrostatics',hyd),('commands',commands),('separation',sep)]:np.savetxt(out/(name+'.csv'),data,delimiter=',')
r=np.asarray(rows);h=np.asarray(hyd);ac=np.asarray(act)
checks={'completed':len(r)>10 and r[-1,0]>=duration,'finite':all(np.isfinite(x).all() for x in [r,h,ac]),'continuous':len(r)>10 and np.max(np.diff(r[:,0]))<.3};metrics={}
criteria=json.loads((root/'tests/scenarios/reverse_task_acceptance.json').read_text())
if len(r)>100:
 tail=r[r[:,0]>duration-15];rate=float(np.degrees(np.polyfit(tail[:,0]-tail[0,0],np.unwrap(tail[:,14]),1)[0]));speed=float(tail[:,10].mean())
 checks['neutral_yaw']=abs(rate)<criteria['max_neutral_yaw_deg_s']
 checks['steady_speed']=float(tail[:,10].std())<criteria['max_tail_speed_std_m_s']
 checks['attitude']=float(np.degrees(abs(r[:,15:17])).max())<criteria['max_roll_pitch_deg']
 checks['actual_zero_rudder']=float(np.degrees(abs(ac[:,1])).max())<.1
 checks['motion_direction']=speed<0 if reverse else speed>0
 checks['propeller_wet']=float(r[r[:,0]>15,8].min())>=criteria['minimum_propeller_wet_fraction']
 metrics={'tail_yaw_deg_s':rate,'tail_surge_m_s':speed,'tail_speed_kmh':abs(speed)*3.6,'speed_std_m_s':float(tail[:,10].std()),'heading_change_deg':float(np.degrees(np.unwrap(r[:,14])[-1]-r[0,14]))}
 if len(sep):
  se=np.asarray(sep);metrics['max_separation_power_w']=float((se[:,4]*se[:,2]+se[:,5]*se[:,3]).max());checks['separation_dissipative']=metrics['max_separation_power_w']<=1e-8
result={'case':case,'checks':{k:bool(v) for k,v in checks.items()},'metrics':metrics,'passed':all(checks.values()),'scope':'Neutral direct-thrust diagnostic; original neutral yaw, speed scatter, attitude and wetness limits; not a recovery test'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)

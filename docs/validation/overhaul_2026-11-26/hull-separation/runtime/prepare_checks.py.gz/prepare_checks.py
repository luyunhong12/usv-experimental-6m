"""在不改变候选参数的情况下准备步长与持续运行对照。"""
from pathlib import Path
import shutil,xml.etree.ElementTree as E
p=Path('/home/yh/Project/usv-experimental-6m/artifacts/rebuild/separation-v1')
for name,source,half in [('halfstep',p/'physical',True),('old_forward',p.parent/'simple-speed15-v1',False)]:
 d=p/name;d.mkdir();shutil.copy(source/'model.sdf',d/'model.sdf');shutil.copy(p/'physical/equilibrium.json',d/'equilibrium.json');w=E.parse(source/'world.sdf');w.getroot().find('world/include/uri').text=str(d/'model.sdf')
 if half:w.getroot().find('world/physics/max_step_size').text='0.0005'
 w.write(d/'world.sdf');run=(p/'physical/run.py').read_text().replace('/rebuild/separation-v1/physical',f'/rebuild/separation-v1/{name}');(d/'run.py').write_text(run)
for name in ['physical','old_forward']:
 run=(p/name/'run.py').read_text();run=run.replace('duration=162 if reverse else 40','duration=240 if reverse else 100').replace('throttle=-.6 if reverse else 0; angle=', 'throttle=-.6 if reverse else 1; angle=0 #')
 start=run.index('if not reverse and len(h)>10:');end=run.index('result={',start)
 assessment='''criteria=json.loads((root/'tests/scenarios/reverse_task_acceptance.json').read_text())
if len(r)>100:
 tail=r[r[:,0]>duration-15];rate=float(np.degrees(np.polyfit(tail[:,0]-tail[0,0],np.unwrap(tail[:,14]),1)[0]));speed=float(tail[:,10].mean())
 checks['neutral_yaw']=abs(rate)<criteria['max_neutral_yaw_deg_s']
 checks['steady_speed']=float(tail[:,10].std())<criteria['max_tail_speed_std_m_s']
 checks['attitude']=float(np.degrees(abs(r[:,15:17])).max())<criteria['max_roll_pitch_deg']
 checks['actual_zero_rudder']=float(np.degrees(abs(ac[:,1])).max())<.1
 checks['motion_direction']=speed<0 if reverse else speed>0
 checks['propeller_wet']=float(r[r[:,0]>15,8].min())>=criteria['minimum_propeller_wet_fraction']
 metrics={'tail_yaw_deg_s':rate,'tail_surge_m_s':speed,'tail_speed_kmh':abs(speed)*3.6,'speed_std_m_s':float(tail[:,10].std()),'heading_change_deg':float(np.degrees(np.unwrap(r[:,14])[-1]-r[0,14]))}
 if len(sep):
  se=np.asarray(sep);metrics['max_separation_power_w']=float((se[:,4]*se[:,2]+se[:,5]*se[:,3]).max());checks['separation_dissipative']=metrics['max_separation_power_w']<=1e-8
'''
 run=run[:start]+assessment+run[end:];run=run.replace("'scope':'40kW speed15 concept fixed-load no-fin candidate; existing criteria unchanged; no heading controller'", "'scope':'Neutral direct-thrust diagnostic; original neutral yaw, speed scatter, attitude and wetness limits; not a recovery test'")
 (p/name/'diagnostic.py').write_text(run)

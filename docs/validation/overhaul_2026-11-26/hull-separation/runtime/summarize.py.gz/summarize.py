"""汇总原始测试，不调整门槛；复用距离走廊几何指标。"""
from pathlib import Path
import ast,json,math
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path('/home/yh/Project/usv-experimental-6m');base=root/'artifacts/rebuild/separation-v1'
criteria=json.loads((root/'tests/scenarios/reverse_task_acceptance.json').read_text())
trace=np.loadtxt(base/'physical/reverse_neutral/propulsion.csv',delimiter=',');origin=trace[0,[12,13,14]];delta=trace[:,12:14]-origin[:2];along=delta[:,0]*np.cos(origin[2])+delta[:,1]*np.sin(origin[2])
tree=ast.parse((root/'tests/regression/assess_maneuvers.py').read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='reverse_task_metrics');ns={'np':np};exec(compile(ast.Module(body=[f],type_ignores=[]),'original_corridor_metric','exec'),ns)
results={}
for distance in [10,30,60]:
 hit=np.flatnonzero(along<=-distance);assert len(hit);r=ns['reverse_task_metrics'](trace[:hit[0]+1],origin);bounds=criteria['reverse_corridors'][str(distance)];r['checks']={'cross_track':r['max_cross_track_m']<=bounds['cross_track_m'],'heading':r['max_heading_error_deg']<=bounds['heading_deg']};results[str(distance)]=r
results['scope']='Postprocessed first 10/30/60m of continuous zero-helm reverse; does not test distance-trigger control.'
(base/'corridors.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
fig,axes=plt.subplots(2,1,figsize=(10,7))
for path,label in [(root/'artifacts/rebuild/section-hydro-v1/inertia_crossflow/reverse_left/propulsion.csv','Before: same sectional inertia and drag'),(base/'physical/reverse_left/propulsion.csv','After: separation correction')]:
 r=np.loadtxt(path,delimiter=',');rate=np.gradient(np.degrees(np.unwrap(r[:,14])),r[:,0]);axes[0].plot(r[:,0],rate,label=label)
axes[0].set_ylabel('Yaw rate (deg/s)');axes[0].legend();axes[0].grid();axes[0].set_title('60% reverse, fixed load, no fin or heading controller')
for case,label in [('reverse_left','+5 degree pulse'),('reverse_right','-5 degree pulse')]:
 r=np.loadtxt(base/'physical'/case/'propulsion.csv',delimiter=',');rate=np.gradient(np.degrees(np.unwrap(r[:,14])),r[:,0]);axes[1].plot(r[:,0]-102,rate,label=label)
reference=json.loads((base/'physical/reverse_left/result.json').read_text())['metrics']['reference_yaw_deg_s']
for y in [reference-.05,reference+.05]:axes[1].axhline(y,color='gray',linestyle='--')
axes[1].axvline(30,color='red',linestyle=':',label='Original 30 s deadline');axes[1].set_xlim(10,60);axes[1].set_ylim(-.5,.5);axes[1].set_xlabel('Seconds after commanded helm returns to zero (nominal)');axes[1].set_ylabel('Yaw rate (deg/s), tail zoom');axes[1].grid();axes[1].legend();fig.tight_layout();fig.savefig(base/'recovery-comparison.png',dpi=160)

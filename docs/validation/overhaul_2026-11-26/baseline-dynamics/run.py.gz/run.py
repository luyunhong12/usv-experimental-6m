import os,time,json,subprocess,signal,math,sys,ast
from pathlib import Path
import xml.etree.ElementTree as E
import numpy as np
from gz.transport13 import Node
from gz.msgs10.double_pb2 import Double
from gz.msgs10.double_v_pb2 import Double_V
root=Path('/home/yh/Project/usv-experimental-6m');base=Path('/rebuild/wave-v1');case=sys.argv[1];out=base/case;out.mkdir(exist_ok=False)
eq=json.loads((Path('/rebuild/recovery-v1')/'equilibrium.json').read_text());world=E.parse('/rebuild/simple-v1/world.sdf');w=world.getroot().find('world');w.set('name','simple_'+case)
for p in list(w.findall('plugin')):
 if p.get('name')=='gz::sim::systems::Sensors':w.remove(p)
pose=[0,0,*[eq['equilibrium_z_roll_pitch'][0]],eq['equilibrium_z_roll_pitch'][1],eq['equilibrium_z_roll_pitch'][2],0]
if case=='disturbed':pose[2]+=.08;pose[3]+=math.radians(5);pose[4]+=math.radians(2)
w.find('include/pose').text=' '.join(map(str,pose));model=E.parse('/rebuild/simple-v1/model.sdf')
for wave in model.findall('.//wavefield/wave'):
 wave.find('gain').text='0.3'
 for key,value in [('direction',0 if case=='head' else math.pi/2),('period',4)]:
  el=wave.find(key)
  if el is None:el=E.SubElement(wave,key)
  el.text=str(value)
model.write(out/'model.sdf');w.find('include/uri').text=str(out/'model.sdf');world.write(out/'world.sdf')
n=Node();rows=[];act=[];hyd=[];commands=[];waves=[]
def rec(m):rows.append(list(m.data))
def servo(m):act.append(list(m.data))
def buoy(m):hyd.append(list(m.data))
n.subscribe(Double_V,'/usv/propulsion/state',rec);n.subscribe(Double_V,'/usv/actuators/state',servo);n.subscribe(Double_V,'/usv/hydrostatics',buoy)
def wave_record(m):waves.append(list(m.data))
n.subscribe(Double_V,'/usv/wave_response/state',wave_record)
a=n.advertise('/usv/propulsion/throttle',Double);b=n.advertise('/usv/steering/angle',Double)
log=(out/'runtime.log').open('w');p=subprocess.Popen(['gz','sim','-s','-r',str(out/'world.sdf')],stdout=log,stderr=log,start_new_session=True)
start=time.monotonic();reverse=case.startswith('reverse');duration=70;laststage=None
try:
 while time.monotonic()-start<500:
  t=rows[-1][0] if rows else 0
  if t>=duration or p.poll() is not None:break
  throttle=-.6 if reverse else 0; angle=(math.radians(5)*(1 if case.endswith('left') else -1)) if reverse and 100<=t<102 else 0
  stage=0 if t<100 else (1 if t<102 else 2)
  if stage!=laststage:commands.append([t,throttle,angle]);laststage=stage
  a.publish(Double(data=throttle));b.publish(Double(data=angle));time.sleep(.02)
finally:
 a.publish(Double(data=0));b.publish(Double(data=0));os.killpg(p.pid,signal.SIGINT)
 try:p.wait(timeout=10)
 except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
 log.close()
for name,data in [('propulsion',rows),('actuators',act),('hydrostatics',hyd),('commands',commands),('waves',waves)]:np.savetxt(out/(name+'.csv'),data,delimiter=',')
r=np.asarray(rows);h=np.asarray(hyd);ac=np.asarray(act)
checks={'completed':len(r)>10 and r[-1,0]>=duration,'finite':all(np.isfinite(x).all() for x in [r,h,ac]),'continuous':len(r)>10 and np.max(np.diff(r[:,0]))<.3};metrics={}
d=np.asarray(waves)
checks['wave_data']=len(d)>100
if len(d)>100:
 tail=d[d[:,0]>25]
 metrics={'heave_peak_to_peak_m':float(np.ptp(tail[:,6])),'roll_peak_to_peak_deg':float(np.rad2deg(np.ptp(tail[:,7]))),'pitch_peak_to_peak_deg':float(np.rad2deg(np.ptp(tail[:,8]))),'surface_peak_to_peak_m':float(np.ptp(tail[:,1])),'max_abs_attitude_deg':float(np.rad2deg(np.max(abs(d[:,7:9]))))}
 checks['attitude_bounded']=metrics['max_abs_attitude_deg']<20
 checks['positive_buoyancy']=bool(np.min(tail[:,11])>0)
 checks['responds_to_waves']=metrics['heave_peak_to_peak_m']>.02 and max(metrics['roll_peak_to_peak_deg'],metrics['pitch_peak_to_peak_deg'])>.1
 checks['wave_input_present']=metrics['surface_peak_to_peak_m']>.02
result={'case':case,'checks':{k:bool(v) for k,v in checks.items()},'metrics':metrics,'passed':all(checks.values()),'scope':'6kW baseline fixed-load no-fin candidate; existing criteria unchanged; no heading controller'};(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
